//
//  CustomizeTextField.h
//  Xem Bóng Đá
//
//  Created by Mr.Lemon on 10/8/13.
//  Copyright (c) 2013 Fruity Solution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomizeTextField : UITextField

@end
