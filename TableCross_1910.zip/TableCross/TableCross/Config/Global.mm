//
//  Global.m
//  SOS APP
//
//  Created by TableCross.hut@gmail.com on 9/1/13.
//  Copyright (c) 2013 TableCross.hut@gmail.com. All rights reserved.
//
#import "Global.h"

NSString *gMemberId=@"";
UINavigationController  *gNavigationViewController;

BOOL gIsLogin=FALSE;
BOOL gIsShowHome= FALSE;
BOOL gIsLoginFacebook;
BOOL gIsHasNetwork=TRUE;
NSString *shareAppMessage= @"Dear friend, please try this app";
NSString *shareAppUrl = @"https://itunes.apple.com/us/app/candy-crush-saga/id553834731?mt=8";
double gCurrentLatitude = 0.0;
double gCurrentLongitude = 0.0;
BOOL gIsEnableLocation = YES;

 NSMutableArray *gArrRestaurant=nil;