//
//  SearchHomeViewController.h
//  TableCross
//
//  Created by TableCross on 14/09/2014.
//  Copyright (c) Năm 2014 Lemon. All rights reserved.
//

#import "BaseViewController.h"
#import "SearchHistoryViewController.h"
#import "SearchBySpecifyViewController.h"

@interface SearchHomeViewController : BaseViewController
- (IBAction)onSearch1Click:(id)sender;
- (IBAction)onSearch2Click:(id)sender;
- (IBAction)onSearch3Click:(id)sender;
- (IBAction)onSearch4Click:(id)sender;



@end
