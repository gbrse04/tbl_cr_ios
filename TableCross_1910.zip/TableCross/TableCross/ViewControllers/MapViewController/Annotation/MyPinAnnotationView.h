//
//  MyPinAnnotationView.h
//  Bus
//
//  Created by duc le on 3/22/14.
//
//

#import <MapKit/MapKit.h>

@interface MyPinAnnotationView : MKAnnotationView

@end
