//
//  SplashViewController.h
//  TableCross
//
//  Created by TableCross on 14/09/2014.
//  Copyright (c) Năm 2014 Lemon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SelectRegionViewController.h"

@interface SplashViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UIView *viewOverlay;

@end
