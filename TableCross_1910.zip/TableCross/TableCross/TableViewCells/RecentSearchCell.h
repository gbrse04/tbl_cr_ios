//
//  RecentSearchCell.h
//  TableCross
//
//  Created by DANGLV on 23/09/2014.
//  Copyright (c) Năm 2014 Lemon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UnderLineLabel.h"


@interface RecentSearchCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UnderLineLabel *lblContent;

@end
