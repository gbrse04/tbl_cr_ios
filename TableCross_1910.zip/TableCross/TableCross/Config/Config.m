//
//  Config.m
//  SOS APP
//
//  Created by Mr.Lemon on 9/4/13.
//  Copyright (c) 2013 TableCross.hut@gmail.com. All rights reserved.
//

#import "Config.h"

@implementation Config

@end
